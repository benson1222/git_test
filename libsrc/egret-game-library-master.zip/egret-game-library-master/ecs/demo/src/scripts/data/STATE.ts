/**
 * Created by jackyanjiaqi on 16-3-21.
 */
module data{
    export enum STATE {
        NORMAL = 1,
        EFFECT_ENABLE = 2,
        DISABLE = 3
    }
}
