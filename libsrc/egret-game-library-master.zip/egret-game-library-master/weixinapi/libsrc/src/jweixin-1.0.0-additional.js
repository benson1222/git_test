var BodyConfig = function(){};
var BodyCheckJsAPISupport = function(){};
var BodyMenuShareTimeline = function(){};
var BodyMenuShareAppMessage = function(){};
var BodyMenuShareQQ = function(){};
var BodyMenuShareWeibo = function(){};